#!/bin/sh
#
# Copyright (C) 2016 by Massimo Lauria
#
# Created   : "2016-11-23, Wednesday 12:19 (CET) Massimo Lauria"
# Time-stamp: "2016-11-24, 00:18 (CET) Massimo Lauria"
#
# Description::
#
# Build pentadactyl extension for a specific version (force version number)
#

# Make shell more robust
# (see http://redsymbol.net/articles/unofficial-bash-strict-mode/#sourcing-nonconforming-document)
set -euo pipefail
IFS=$'\n\t'

MAXVERSION=${1-60}
BUILDDIR=~/.dactyl
OLDPWD=$PWD
REPOSITORY=https://github.com/5digits/dactyl.git

echo "Build Pentadactyl (unsigned) for unbranded firefox (max supported version forced to $MAXVERSION)"

# Update the repo
if [ -d $BUILDDIR ]; then
    echo "Pentadactyl is here. I'll update the repository"
    cd $BUILDDIR
    git reset --hard
    git pull
else
    echo "Pentadactyl is not here. I'll clone the repository"
    git clone --depth 10  $REPOSITORY $BUILDDIR
    cd $BUILDDIR
fi

# Bump up the version
BACKUP=pentadactyl/install.rdf.bak
TARGET=pentadactyl/install.rdf
cp $TARGET $BACKUP
sed "/em:maxVersion=[\\\"0-9\\\*\\\.]*/s//em:maxVersion=\"${MAXVERSION}.*\"/" $BACKUP > $TARGET

# Build it
make -C pentadactyl xpi
make -C pentadactyl install

# Exit
cd $OLDPWD

# Local Variables:
# fill-column: 80
# End:
