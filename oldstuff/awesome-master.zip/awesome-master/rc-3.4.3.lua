-- Standard awesome library
require("awful")
require("awful.autofocus")
require("awful.rules")

require("debian.menu")

-- Theme handling library
theme=require("beautiful")
-- Notification library
require("naughty")

naughty.config.icon_dirs = { "/usr/share/pixmaps/",
                            "/usr/share/icons/Tango/16x16/status/",
                            "/usr/share/icons/Tango/16x16/devices/",
                            "/usr/share/icons/Tango/16x16/actions/",
                            "/usr/share/icons/Tango/16x16/apps/",
                            "/usr/share/icons/Human/16x16/status/",
                            "/usr/share/icons/Human/16x16/devices/",
                            "/usr/share/icons/Human/16x16/actions/",
                            "/usr/share/icons/Human/16x16/apps/",
                            "/usr/share/icons/gnome/16x16/status/",
                            "/usr/share/icons/gnome/16x16/devices/",
                            "/usr/share/icons/gnome/16x16/actions/",
                            "/usr/share/icons/gnome/16x16/apps/"
                         }

---------------  CUSTOM LIBRARIES -------------------------------------
custom_config_path=os.getenv("HOME") .. "/config/awesome"
package.path = package.path .. ";" .. custom_config_path .. "/?.lua"

-- My own packages
require("narrowwriter")

-- Addons
require("eminent")
-----------------------------------------------------------------------

-- {{{ Variable definitions
-- Themes define colours, icons, and wallpapers
beautiful.init(os.getenv("HOME") .. "/config/awesome/theme-3.4.3.lua")

-- This is used later as the default terminal and editor to run.
terminal = "xterm"
editor = os.getenv("EDITOR") or "emacsclient"
editor_cmd = terminal .. " -e " .. editor

-- Default modkey.
-- Usually, Mod4 is the key with a logo between Control and Alt.
-- If you do not like this or do not have such a key,
-- I suggest you to remap Mod4 to another key using xmodmap or other tools.
-- However, you can use another modifier like Mod1, but it may interact with others.
modkey = "Mod4"

-- Table of layouts to cover with awful.layout.inc, order matters.
layouts =
{
   awful.layout.suit.tile.right,
   -- awful.layout.suit.tile.left,
   -- awful.layout.suit.tile.bottom,
   -- awful.layout.suit.tile.top,
   awful.layout.suit.max,
   -- awful.layout.suit.tile,
   narrowwriter,
   awful.layout.suit.tile.top,
   -- awful.layout.suit.fair
}
-- }}}

-- {{{ Tags
-- Define a tag table which hold all screen tags.
tags = {}
for s = 1, screen.count() do
    -- Each screen has its own tag table.
    tags[s] = awful.tag({"1:main","2:aux","3:fm", "4:web", "5:media", "6:p2p", "7:sys"}, s, layouts[1])
end
-- }}}

-- {{{
if screen.count() > 1 then
   screenMain = 1
   screenLeft = 2
else
   screenMain = 1
   screenLeft = screenMain
end
naughty.config.default_preset.screen = screenMain   

-- }}}


-- {{{ Menu
-- Create a laucher widget and a main menu
myawesomemenu = {
   { "Manual", terminal .. " -e man awesome" },
   { "edit config", editor_cmd .. " " .. awful.util.getdir("config") .. "/rc.lua" },
   { "restart", awesome.restart },
   { "quit", awesome.quit }
}

mymainmenu = awful.menu({ items = { { "awesome", myawesomemenu, beautiful.awesome_icon },
                                    { "Debian", debian.menu.Debian_menu.Debian },
                                    { "open terminal", terminal }
                                  }
                        })

mylauncher = awful.widget.launcher({ image = image(beautiful.awesome_icon),
                                     menu = mymainmenu })
-- }}}

-- {{{ Wibox
-- Create a textclock widget
mytextclock = awful.widget.textclock({ align = "right" }," %A, %d %B %Y - %H:%M ")

-- Unfortunately it can't parse my org files.
require("orglendar")
orglendar.files = {
   os.getenv("HOME")  .. "/personal/agenda/agenda.org",
   os.getenv("HOME") .. "/personal/agenda/notebook.org" }
orglendar.register(mytextclock)

-- Create a systray
mysystray = widget({ type = "systray" })

-- Create a wibox for each screen and add it
mywibox = {}
mypromptbox = {}
mylayoutbox = {}
mytaglist = {}
mytaglist.buttons = awful.util.table.join(
                    awful.button({ }, 1, awful.tag.viewonly),
                    awful.button({ modkey }, 1, awful.client.movetotag),
                    awful.button({ }, 3, awful.tag.viewtoggle),
                    awful.button({ modkey }, 3, awful.client.toggletag),
                    awful.button({ }, 4, awful.tag.viewnext),
                    awful.button({ }, 5, awful.tag.viewprev)
                    )



mytasklist = {}
mytasklist.buttons = awful.util.table.join(
                     awful.button({ }, 1, function (c)
                                              if not c:isvisible() then
                                                  awful.tag.viewonly(c:tags()[1])
                                              end
                                              client.focus = c
                                              c:raise()
                                          end),
                     awful.button({ }, 3, function ()
                                              if instance then
                                                  instance:hide()
                                                  instance = nil
                                              else
                                                  instance = awful.menu.clients({ width=250 })
                                              end
                                          end),
                     awful.button({ }, 4, function ()
                                              awful.client.focus.byidx(1)
                                              if client.focus then client.focus:raise() end
                                          end),
                     awful.button({ }, 5, function ()
                                              awful.client.focus.byidx(-1)
                                              if client.focus then client.focus:raise() end
                                          end))

for s = 1, screen.count() do
    -- Create a promptbox for each screen
    mypromptbox[s] = awful.widget.prompt({ layout = awful.widget.layout.horizontal.leftright })
    -- Create an imagebox widget which will contains an icon indicating which layout we're using.
    -- We need one layoutbox per screen.
    mylayoutbox[s] = awful.widget.layoutbox(s)
    mylayoutbox[s]:buttons(awful.util.table.join(
                           awful.button({ }, 1, function () awful.layout.inc(layouts, 1) end),
                           awful.button({ }, 3, function () awful.layout.inc(layouts, -1) end),
                           awful.button({ }, 4, function () awful.layout.inc(layouts, 1) end),
                           awful.button({ }, 5, function () awful.layout.inc(layouts, -1) end)))
    -- Create a taglist widget
    mytaglist[s] = awful.widget.taglist(s, awful.widget.taglist.label.all, mytaglist.buttons)

    -- Create a tasklist widget
    mytasklist[s] = awful.widget.tasklist(function(c)
                                              return awful.widget.tasklist.label.currenttags(c, s)
                                          end, mytasklist.buttons)

    -- Create the wibox
    mywibox[s] = awful.wibox({ position = "top", screen = s })
    -- Add widgets to the wibox - order matters
    mywibox[s].widgets = {
        {
           -- mylauncher,
           mypromptbox[s],
           mytaglist[s],
           mylayoutbox[s],
           layout = awful.widget.layout.horizontal.leftright
        },
        s == screenMain and mysystray or nil,
        s == screenMain and mytextclock or nil,
        mytasklist[s],
        layout = awful.widget.layout.horizontal.rightleft
    }
end
-- }}}

-- {{{ Mouse bindings
root.buttons(awful.util.table.join(
    awful.button({ }, 3, function () mymainmenu:toggle() end),
    awful.button({ }, 4, awful.tag.viewnext),
    awful.button({ }, 5, awful.tag.viewprev)
))
-- }}}

-- {{{ Key bindings
globalkeys = awful.util.table.join(

    -- Tag browsing
    awful.key({ modkey,           }, "Left",   awful.tag.viewprev       ),
    awful.key({ modkey,           }, "Right",  awful.tag.viewnext       ),

    awful.key({ modkey,           }, "u",      awful.tag.viewprev       ),
    awful.key({ modkey,           }, "o",      awful.tag.viewnext       ),

    -- awful.key({ modkey,           }, "d",      awful.tag.viewprev       ),
    -- awful.key({ modkey,           }, "f",      awful.tag.viewnext       ),
    awful.key({ modkey,           }, "Tab"  , awful.tag.history.restore),

    -- Focus keystrokes
    awful.key({ modkey,           }, "i",
        function ()
            awful.client.focus.byidx(-1)
            if client.focus then client.focus:raise() end
        end),
    awful.key({ modkey,           }, "k",
        function ()
            awful.client.focus.byidx( 1)
            if client.focus then client.focus:raise() end
        end),

    -- not very general 
    awful.key({ modkey, }, "XF86Back",    function () awful.screen.focus(screenLeft) end),
    awful.key({ modkey, }, "XF86Forward", function () awful.screen.focus(screenMain) end),
    

    --  awful.key({ modkey,           }, "u", awful.client.urgent.jumpto),
    --  awful.key({ modkey,           }, "Tab",
    --      function ()
    --        awful.client.focus.history.previous()
    --        if client.focus then
    --            client.focus:raise()
    --      end
    --  end),

    -- Menu
    -- awful.key({ modkey,           }, "w", function () mymainmenu:show(true)        end),

    awful.key({ modkey,           }, "Home",  awful.screen.focus(screenMain) ),
    awful.key({ modkey,           }, "End" ,  awful.screen.focus(screenMain) ),

    awful.key({ modkey,           }, "Prior",  awful.screen.focus_relative(screenLeft) ),
    awful.key({ modkey,           }, "Next" ,  awful.screen.focus_relative(screenMain) ),


    -- Layout management (resize,master-slave ratio,slave columns)
    awful.key({ modkey,           }, "b", function ()
        if mywibox[mouse.screen].screen==nil then
           mywibox[mouse.screen].screen = mouse.screen
        else
           mywibox[mouse.screen].screen = nil
        end
    end),

    awful.key({ modkey, "Shift"   }, "i", function () awful.client.swap.byidx( -1)    end),
    awful.key({ modkey, "Shift"   }, "k", function () awful.client.swap.byidx(  1)    end),

    awful.key({ modkey, "Control" }, "i", function () awful.screen.focus_relative( 1) end),
    awful.key({ modkey, "Control" }, "k", function () awful.screen.focus_relative(-1) end),

    awful.key({ modkey,           }, "j",     function () awful.tag.incmwfact(-0.05)    end),
    awful.key({ modkey,           }, "l",     function () awful.tag.incmwfact( 0.05)    end),

    awful.key({ modkey, "Shift"   }, "j",     function () awful.tag.incnmaster( 1)      end),
    awful.key({ modkey, "Shift"   }, "l",     function () awful.tag.incnmaster(-1)      end),

    awful.key({ modkey, "Control" }, "j",     function () awful.tag.incncol(-1)         end),
    awful.key({ modkey, "Control" }, "l",     function () awful.tag.incncol( 1)         end),

    awful.key({ modkey,           }, "space", function () awful.layout.inc(layouts,  1) end),
    awful.key({ modkey, "Shift"   }, "space", function () awful.layout.inc(layouts, -1) end),


    -- Standard program
    awful.key({ modkey,           }, "Return", function () awful.util.spawn(terminal) end),
    awful.key({ modkey, "Shift"   }, "r", awesome.restart),
    awful.key({ modkey, "Shift"   }, "q", awesome.quit),


    -- Prompt (Apps and Lua)
    awful.key({ modkey },            "r",     function () mypromptbox[mouse.screen]:run() end),
    awful.key({ modkey }, "x",
              function ()
                  awful.prompt.run({ prompt = "Run Lua code: " },
                  mypromptbox[mouse.screen].widget,
                  awful.util.eval, nil,
                  awful.util.getdir("cache") .. "/history_eval")
              end)
)

ban_client_other_screen=function (c)
   local focus_screen = client.focus.screen
   local other_screen = screen.count() + 1 - focus_screen 
   awful.client.movetoscreen(c,other_screen)
   awful.screen.focus(focus_screen)
end

grab_client_other_screen=function ()
   local  this_screen = client.focus.screen
   local other_screen = screen.count() + 1 - this_screen 
   local other_master = awful.client.getmaster(other_screen)
   awful.client.movetoscreen(other_master,this_screen)
   awful.client.setmaster(other_master)
end


clientkeys = awful.util.table.join(
    awful.key({ modkey, "Shift"   }, "m",      function (c) c.fullscreen = not c.fullscreen  end),
    awful.key({ modkey,           }, "Escape", function (c) c:kill()                         end),
    awful.key({ modkey,           }, ".",      awful.client.floating.toggle                     ),
    awful.key({ modkey,           }, "m", function (c) c:swap(awful.client.getmaster()) end),
    -- awful.key({ modkey,           }, "Insert", awful.client.togglemarked),

    
    -- ,

    awful.key({ modkey, "Shift" }, "XF86Back",    function (c) awful.client.movetoscreen(c,screenLeft) end),
    awful.key({ modkey, "Shift" }, "XF86Forward", function (c) awful.client.movetoscreen(c,screenMain) end),   
    awful.key({ modkey,              }, "a",      awful.client.movetoscreen                        )
    -- awful.key({ modkey, "Shift"   }, "r",      function (c) c:redraw()                       end),
    -- awful.key({ modkey,           }, "n",      function (c) c.minimized = not c.minimized    end),
    -- awful.key({ modkey,           }, "m",
    --     function (c)
    --         c.maximized_horizontal = not c.maximized_horizontal
    --         c.maximized_vertical   = not c.maximized_vertical
    --     end)
)

-- Compute the maximum number of digit we need, limited to 9
keynumber = 0
for s = 1, screen.count() do
   keynumber = math.min(9, math.max(#tags[s], keynumber));
end

-- Bind all key numbers to tags.
-- Be careful: we use keycodes to make it works on any keyboard layout.
-- This should map on the top row of your keyboard, usually 1 to 9.
for i = 1, keynumber do
    globalkeys = awful.util.table.join(globalkeys,
        awful.key({ modkey }, "#" .. i + 9,
                  function ()
                        local screen = mouse.screen
                        if tags[screen][i] then
                            awful.tag.viewonly(tags[screen][i])
                        end
                  end),
        awful.key({ modkey, "Control" }, "#" .. i + 9,
                  function ()
                      local screen = mouse.screen
                      if tags[screen][i] then
                          awful.tag.viewtoggle(tags[screen][i])
                      end
                  end),
        awful.key({ modkey, "Shift" }, "#" .. i + 9,
                  function ()
                      if client.focus and tags[client.focus.screen][i] then
                          awful.client.movetotag(tags[client.focus.screen][i])
                      end
                  end),
        awful.key({ modkey, "Control", "Shift" }, "#" .. i + 9,
                  function ()
                      if client.focus and tags[client.focus.screen][i] then
                          awful.client.toggletag(tags[client.focus.screen][i])
                      end
                  end))
end

clientbuttons = awful.util.table.join(
    awful.button({ }, 1, function (c) client.focus = c; c:raise() end),
    awful.button({ modkey }, 1, awful.mouse.client.move),
    awful.button({ modkey }, 3, awful.mouse.client.resize))

-- Set keys
root.keys(globalkeys)
-- }}}

-- {{{ Rules
awful.rules.rules = {
    -- All clients will match this rule.
    { rule = { },
      properties = { border_width = beautiful.border_width,
                     border_color = beautiful.border_normal,
                     focus = true,
                     keys = clientkeys,
                     buttons = clientbuttons,

                     -- never start maximized
                     maximized_vertical   = false,
                     maximized_horizontal = false  } },

    -- These application will float.
    { rule = { class = "MPlayer" },  properties = { floating = true } },
    { rule = { class = "pinentry" }, properties = { floating = true } },
    { rule = { class = "gimp" },     properties = { floating = true } },
    { rule = { class = "vlc" },      properties = { floating = true } },
    { rule = { class = "Xmessage" }, properties = { floating = true } },
    { rule = { class = "feh" }, properties = { floating = true } },

    -- Tags number for applications.

    -- 1:main
    { rule = { class = "Openoffice.org" },  properties = { tag = tags[screenMain][1] } },
    { rule = { class = "XDvi" },    properties = { tag = tags[screenLeft][2] } },
    { rule = { class = "Xpdf" },    properties = { tag = tags[screenLeft][2] } },
    { rule = { class = "Evince" },  properties = { tag = tags[screenLeft][2] } },
    -- 2:aux
    -- 3:fm
    { rule = { class = "Pcmanfm" },  properties = { tag = tags[screenMain][3] } },
    { rule = { class = "Nautilus" }, properties = { tag = tags[screenMain][3] } },
    { rule = { class = "Thunar" },   properties = { tag = tags[screenMain][3] } },
    -- 4:web
    { rule = { class = "X-www-browser"   },   properties = { tag = tags[screenMain][4] } },
    { rule = { class ="Gnome-www-browser"},   properties = { tag = tags[screenMain][4] } },
    { rule = { class = "Google-chrome"   },   properties = { tag = tags[screenMain][4] } },
    { rule = { class = "Google-chrome.real"}, properties = { tag = tags[screenMain][4] } },
    { rule = { class = "Firefox"   },         properties = { tag = tags[screenMain][4] } },
    { rule = { class = "Iceweasel" },         properties = { tag = tags[screenMain][4] } },
    { rule = { class = "Conkeror" },          properties = { tag = tags[screenMain][4] } },
    { rule = { class = "Skype" },             properties = { tag = tags[screenMain][4] } },
    -- 5:media
    { rule = { class = "Gmpc" },   properties = { tag = tags[screenLeft][5] } },
    { rule = { class = "Sonata" }, properties = { tag = tags[screenLeft][5] } },
    { rule = { class = "Miro" },   properties = { tag = tags[screenLeft][5] } },
    -- 6:p2p
    { rule = { class = "Amule"        }, properties = { tag = tags[screenLeft][6] } },
    { rule = { class = "Transmission" }, properties = { tag = tags[screenLeft][6] } },
    -- 7:sys
    { rule = { class = "Gnome-system-monitor" }, properties = { tag = tags[screenLeft][7] } }

}
-- }}}

-- {{{ Signals
-- Signal function to execute when a new client appears.
client.add_signal("manage", function (c, startup)
    -- Add a titlebar
    -- awful.titlebar.add(c, { modkey = modkey })

    -- Disable sloppy focus
    -- c:add_signal("mouse::enter", function(c)
    --    if awful.layout.get(c.screen) ~= awful.layout.suit.magnifier
    --        and awful.layout.get(c.screen) ~= narrowwriter
    --        and awful.client.focus.filter(c) then
    --         client.focus = c
    --     end
    -- end)

    if not startup then
       -- Set the windows at the slave,
       -- i.e. put it at the end of others instead of setting it master.
       -- awful.client.setslave(c)

       -- Put windows in a smart way, only if they does not set an initial position.
       if not c.size_hints.user_position and not c.size_hints.program_position then
          awful.placement.no_overlap(c)
          awful.placement.no_offscreen(c)
       end
    end

end)

client.add_signal("focus",
                  function(c)
                     local disposable_timer = timer({ timeout = 0.5 })
                     local colors = { "#ff0000", "#00ff00", "#0000ff" }
                     colors[screenMain] = "#ff0000"
                     colors[screenLeft] = "#00ff00"
                     disposable_timer:add_signal("timeout", function ()
                                                               if disposable_timer.started then
                                                                  disposable_timer:stop()
                                                               end
                                                               if client.focus == c then
                                                                  c.border_color=beautiful.border_focus
                                                               end
                                                            end)
                     disposable_timer:start()
                     c.border_color = colors[client.focus.screen]
                     c.opacity = beautiful.opacity_focus
                  end)
client.add_signal("unfocus",
                  function(c)
                     c.border_color = beautiful.border_normal
                     c.opacity = beautiful.opacity_focus
                  end)
-- }}}
