#!/bin/bash
# Run Awesome in a nested server for tests
#
# Requirements: (Debian/Ubuntu)
#
#  apt-get install xserver-xephyr
#  apt-get install awesome
#
# Based on original script by dante4d <dante4d@gmail.com>
# See: http://awesome.naquadah.org/wiki/index.php?title=Using_Xephyr
#
# URL: http://hellekin.cepheide.org/awesome/awesome_test
#
# Copyright (c) 2009 Hellekin O. Wolf <hellekin@cepheide.org>
#
# 2010 Modified by Massimo Lauria <lauria.massimo@gmail.com>
# (url. http://github.com/MassimoLauria/awesome-config/blob/master/awesome-test.sh)
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# 

function usage() 
{
  cat <<USAGE
awesome-test.sh start|stop|restart|run

  start  <rc-file>  Start nested Awesome in Xephyr which load <rc-file>
  stop              Stop Xephyr
  restart           Reload nested Awesome configuration
  run               Run command in nested Awesome

  Do not run any other awesome instance after the started one.

USAGE
  exit 0
}

# WARNING: the following two functions expect that you only run one instance
# of Xephyr and the last launched Awesome runs in it

function awesome_pid() 
{
  /bin/pidof awesome | cut -d\  -f1
}

function xephyr_pid()
{
  /bin/pidof Xephyr | cut -d\  -f1
}

# Between one and two parameters.
[ $# -lt 1 ] && usage
[ $# -gt 2 ] && usage

# Two parameters are correct only for starting awesome.
if [ x$1 = xstart ]; then
    [ $# -eq 1 ] && RC_LUA=~/.config/awesome/rc.lua
    [ $# -eq 2 ] && RC_LUA=$2
else
    [ $# -eq 1 ] || usage   
fi

# If RC_LUA is missing, quit.
test -f $RC_LUA || (echo "$RC_LUA is missing." && exit -1)

# Just in case we're not running from /usr/bin
AWESOME=`which awesome`
XEPHYR=`which Xephyr`

test -x $AWESOME || { echo "Awesome executable not found. Please install Awesome"; exit 1; }
test -x $XEPHYR || { echo "Xephyr executable not found. Please install Xephyr"; exit 1; }

case "$1" in
  start)
    $XEPHYR -ac -br -noreset -screen 800x600 :1 &
    sleep 1
    DISPLAY=:1.0 $AWESOME -c $RC_LUA &
    sleep 1
    echo Awesome ready for tests. PID is $(awesome_pid)
    ;;
  stop)
    echo -n "Stopping Nested Awesome... "
    if [ -z $(xephyr_pid) ]; then
      echo "Not running: not stopped :)"
      exit 0
    else
      kill $(xephyr_pid)
      echo "Done."
    fi
    ;;
  restart)
    echo -n "Restarting Awesome... "
    kill -s SIGHUP $(awesome_pid)
    ;;
  run)
    shift
    DISPLAY=:1.0 "$@" &
    ;;
  *)
    usage
    ;;
esac
