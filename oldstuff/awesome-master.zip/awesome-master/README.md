# awesome
My config files for awesomewm

This repository is obsolete and it has been archived.
